package com.example.loginscreen;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class NextActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        String name = getIntent().getStringExtra("NAME");
        int score = getIntent().getIntExtra("SCORE", 0);

        Intent intent = new Intent(NextActivity.this, ScoreActivity.class);
        intent.putExtra("NAME", name);
        intent.putExtra("SCORE", score);
        startActivity(intent);
        finish();
    }
}
