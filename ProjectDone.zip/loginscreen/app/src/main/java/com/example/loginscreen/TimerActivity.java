package com.example.loginscreen;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class TimerActivity extends AppCompatActivity {

    private static final long TIMER_DURATION = 6000;
    private TextView countdownTextView;
    private TextView scoreTextView;
    private CountDownTimer countDownTimer;
    private int score = 90246;
    private String name;
    private boolean timerEnded = false;

    private List<Integer> allScores = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        countdownTextView = findViewById(R.id.countdownTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        Button increaseScoreButton = findViewById(R.id.increaseScoreButton);

        name = getIntent().getStringExtra("NAME");

        startTimer();

        increaseScoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!timerEnded) {
                    increaseScore(10);
                    updateScoreTextView();
                }
            }
        });
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(TIMER_DURATION, 1000 / 60) {
            public void onTick(long millisUntilFinished) {
                countdownTextView.setText(String.valueOf(millisUntilFinished / 1000));
            }

            public void onFinish() {
                timerEnded = true;
                countdownTextView.setText("Time's up!");
                showScoreDialog();
            }
        }.start();
    }

    private void showScoreDialog() {
        findViewById(R.id.mainLayout).setEnabled(false);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_score, null);
        builder.setView(dialogView);
        builder.setCancelable(false);

        TextView dialogScoreTextView = dialogView.findViewById(R.id.dialogScoreTextView);
        dialogScoreTextView.setText("Score: " + score);

        Button replayButton = dialogView.findViewById(R.id.replayButton);
        Button homeButton = dialogView.findViewById(R.id.homeButton);

        final AlertDialog alertDialog = builder.create();

        replayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.mainLayout).setEnabled(true);
                startTimer();
                alertDialog.dismiss();
            }
        });

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.mainLayout).setEnabled(true);

                int[] scores = retrievelist10ScoresHistory(name);
                scores = shiftScoresDown(scores);
                scores[0] = score;
                saveList10ScoresHistory(name, scores);

                allScores.add(score);
                saveScoresHistory(name, allScores);

                int highestScore = getHighestScore(name);
                if (score > highestScore) {
                    saveHighestScore(name, score);
                }

                Intent intent = new Intent(TimerActivity.this, GameScreen.class);
                intent.putExtra(GameScreen.EXTRA_NAME, name);
                startActivity(intent);

                alertDialog.dismiss();
            }
        });

        alertDialog.show();
    }

    private void saveList10ScoresHistory(String name, int[] scores) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        for (int i = 0; i < scores.length; i++) {
            editor.putInt(name + "_score_" + (i + 1), scores[i]);
        }
        editor.apply();
    }

    private int[] retrievelist10ScoresHistory(String name) {
        int[] scores = new int[10];
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        for (int i = 0; i < scores.length; i++) {
            scores[i] = sharedPreferences.getInt(name + "_score_" + (i + 1), 0);
        }
        return scores;
    }


    private void saveScoresHistory(String name, List<Integer> scores) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        int highestScore = getHighestScore(name);

        for (int i = 0; i < scores.size(); i++) {
            int currentScore = scores.get(i);
            editor.putInt(name + "_score_" + (i + 1), currentScore);

            if (currentScore > highestScore) {
                highestScore = currentScore;
            }
        }

        editor.putInt(name + "_highest_score", highestScore);

        editor.apply();
    }

    private int getHighestScore(String name) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        return sharedPreferences.getInt(name + "_highest_score", 0);
    }

    private void saveHighestScore(String name, int score) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(name + "_highest_score", score);
        editor.apply();
    }

    private List<Integer> retrieveScoresHistory(String name) {
        List<Integer> scores = new ArrayList<>();
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        int i = 1;
        while (true) {
            int score = sharedPreferences.getInt(name + "_score_" + i, -1);
            if (score == -1) {
                break;
            }
            scores.add(score);
            i++;
        }
        return scores;
    }

    private void updateScoreTextView() {
        scoreTextView.setText("Score: " + score);
    }

    private void increaseScore(int points) {
        score += points;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTimer();
    }

    private void stopTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

    private int[] shiftScoresDown(int[] scores) {
        for (int i = scores.length - 1; i > 0; i--) {
            scores[i] = scores[i - 1];
        }
        return scores;
    }
}
